@include('admin.layouts.header')
@include('admin.layouts.sidebar')
<div class="content-wrapper">
    @yield('content')
</div>
@include('admin.layouts.footer')
