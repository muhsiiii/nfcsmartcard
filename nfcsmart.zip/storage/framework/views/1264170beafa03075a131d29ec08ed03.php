<?php $__env->startSection('content'); ?>
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0 text-dark">Users</h1>
                </div><!-- /.col -->
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="/admin">DashBoard</a></li>
                        <li class="breadcrumb-item active">
                            <a href="https://thalirnaturalsolutions.com/admin/products">Registrations</a>
                        </li>
                        <li class="breadcrumb-item active">Add Users</li>
                    </ol>
                </div><!-- /.col -->
            </div><!-- /.row -->
        </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->
    <div class="row m-10">
        <div class="col-12">
            <div class="card card-primary">
                <div class="card-header">
                    <h3 class="card-title">Add Users</h3>
                </div>
                <!-- form start -->
                <form action="">
                    <div class="card-body">
                        <div class="form-group row">
                            <label for="name" class="col-sm-3 col-form-label text-right">First Name:</label>
                            <div class="col-sm-6">
                                <input type="text" id="fname" class="form-control" placeholder="Enter First Name">
                                <div class="fnameerror" style="color:red;font-size:15px"></div>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="name" class="col-sm-3 col-form-label text-right">Last Name:</label>
                            <div class="col-sm-6">
                                <input type="text" id="lname" class="form-control" placeholder="Enter Last Name">
                                <div class="lnameerror" style="color:red;font-size:16px"></div>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="name" class="col-sm-3 col-form-label text-right">Email Address:</label>
                            <div class="col-sm-6">
                                <input type="email" id="email" class="form-control" placeholder="Enter Email Address">
                                <div class="emailerror" style="color:red;font-size:16px"></div>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="name" class="col-sm-3 col-form-label text-right">Password:</label>
                            <div class="col-sm-6">
                                <input type="password" id="password" class="form-control" placeholder="Enter Password">
                                <div class="passworderror" style="color:red;font-size:16px"></div>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="name" class="col-sm-3 col-form-label text-right">Confirm Password:</label>
                            <div class="col-sm-6">
                                <input type="password" id="confirmPassword" class="form-control" placeholder="Confirm Password">
                                <div class="confirmPassworderror" style="color:red;font-size:16px"></div>
                            </div>
                        </div>


                    </div>

                    <div class="card-footer d-flex justify-content-center">
                        <button type="button" class="btn btn-primary" onclick="UserSave()"> Save </button>
                    </div>
                    <!-- /.card-body -->
                </form>
            </div>
            <!-- /.card -->
        </div>
    </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.js.user_js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\myprojects\NFCsmartcard\resources\views/admin/registeration/user_register_form.blade.php ENDPATH**/ ?>