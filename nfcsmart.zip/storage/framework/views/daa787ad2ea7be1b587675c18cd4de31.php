

<body class="hold-transition sidebar-mini layout-fixed">

<div class="wrapper">
	<nav class="main-header navbar navbar-expand navbar-white navbar-light">
	<!-- Left navbar links -->
	<ul class="navbar-nav">
		<li class="nav-item">
			<a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
		</li>
	</ul>
	<ul class="navbar-nav ml-auto ">
		<li class="nav-item">
			<a class="nav-link" href="#">
				<i class="fa fa-user" aria-hidden="true"></i>
				 &nbsp;ADARSHJOSE
				</a>
		</li>
		<li class="nav-item" >
			<a class="nav-link" href="">
				<i class="fas fa-sign-out-alt"></i> &nbsp;Logout
			</a>
		</li>
	</ul>
</nav>
<!-- /.navbar -->	<!-- Main Sidebar Container -->
<aside class="main-sidebar sidebar-dark-primary elevation-4">
	<!-- Brand Logo -->
	<a href="https://thalirnaturalsolutions.com/admin" class="brand-link">
		<img src="" alt="NFC" class="brand-image img-circle elevation-3" style="opacity: .8">
    <span class="brand-text" style="margin-left: 0px;"><b>NFC</b></span>
	</a>

	<!-- Sidebar -->
	<div class="sidebar">

		<!-- Sidebar Menu -->
		<nav class="mt-2">
			<ul class="nav nav-pills nav-sidebar flex-column nav-child-indent" data-widget="treeview" role="menu" data-accordion="false">

				<!-- Dashboard Side Menus -->
				<li class="nav-item has-treeview">
					<a href="" class="nav-link  active ">
						<i class="nav-icon fa fa-home"></i>
						<p>Dashboard</p>
					</a>
				</li>

        <li class="nav-item has-treeview ">
          <a href="#" class="nav-link ">
            <i class="nav-icon far fa-image" ></i>
            <p>Banners<i class="right fas fa-angle-left"></i></p>
          </a>
          <ul class="nav nav-treeview">
            <li class="nav-item">
              <a href="/admin/banners/first" class="nav-link  ">
                <i class="far fa-circle nav-icon"></i>
                <p class="fs-15">First Banners</p>
              </a>
            </li>

            <li class="nav-item">
              <a href="/admin/banners/third" class="nav-link  ">
                <i class="far fa-circle nav-icon"></i>
                <p class="fs-15">First Banners(Mobile)</p>
              </a>
            </li>

            <li class="nav-item">
              <a href="/admin/banners/second" class="nav-link ">
                <i class="far fa-circle nav-icon"></i>
                <p class="fs-15">Second Banners</p>
              </a>
            </li>

          </ul>
        </li>

				<li class="nav-item has-treeview">
					<a href="https://thalirnaturalsolutions.com/admin/category" class="nav-link ">
						<i class="nav-icon fa fa-th-large"></i>
						<p>Category</p>
					</a>
				</li>

            <li class="nav-item has-treeview">
					<a href="https://thalirnaturalsolutions.com/admin/subcategory" class="nav-link ">
						<i class="nav-icon fa fa-th-large"></i>
						<p>SubCategory</p>
					</a>
				</li>

				<li class="nav-item has-treeview">
					<a href="https://thalirnaturalsolutions.com/admin/products" class="nav-link ">
						<i class="nav-icon fa fa-boxes"></i>
						<p>Products</p>
					</a>
				</li>

        <li class="nav-item has-treeview">
          <a href="https://thalirnaturalsolutions.com/admin/orders" class="nav-link ">
            <i class="nav-icon fa fa-list-ol"></i>
            <p>
              Orders
              <span class="right badge badge-danger">100
              </span>
            </p>
          </a>
        </li>

        <li class="nav-item has-treeview">
          <a href="https://thalirnaturalsolutions.com/admin/customers" class="nav-link ">
            <i class="nav-icon fa fa-users"></i>
            <p>Customers</p>
          </a>
        </li>

        <li class="nav-item has-treeview">
          <a href="https://thalirnaturalsolutions.com/admin/notifications" class="nav-link ">
            <i class="nav-icon fa fa-bell"></i>
            <p>Notifications</p>
          </a>
        </li>

        <li class="nav-item has-treeview hide">
          <a href="https://thalirnaturalsolutions.com/admin/analytics" class="nav-link ">
            <i class="nav-icon fa fa-chart-line"></i>
            <p>Analytics</p>
          </a>
        </li>

        <li class="nav-item has-treeview">
          <a href="https://thalirnaturalsolutions.com/admin/blogs" class="nav-link ">
            <i class="nav-icon fa fa-blog"></i>
            <p>Blogs</p>
          </a>
        </li>

        <li class="nav-item has-treeview">
          <a href="https://thalirnaturalsolutions.com/admin/reviews" class="nav-link ">
            <i class="nav-icon fa fa-star"></i>
            <p>Reviews</p>
          </a>
        </li>

        <li class="nav-item has-treeview">
          <a href="https://thalirnaturalsolutions.com/admin/settings" class="nav-link ">
            <i class="nav-icon fa fa-cogs"></i>
            <p>Settings</p>
          </a>
        </li>

			</ul>
		</nav>
	</div>
</aside>
	<!-- Content Wrapper. Contains page content -->
	<div class="content-wrapper">
		<!-- Content Header (Page header) -->
<div class="content-header">
	<div class="container-fluid">
		<div class="row mb-2">
			<div class="col-sm-6">
				<h1 class="m-0 text-dark">Dashboard</h1>
			</div><!-- /.col -->
			<div class="col-sm-6">
				<ol class="breadcrumb float-sm-right">
											<li class="breadcrumb-item">DashBoard</li>
																			</ol>
		</div><!-- /.col -->
		</div><!-- /.row -->
	</div><!-- /.container-fluid -->
</div>
<!-- /.content-header -->
		<section class="content">
			<div class="container-fluid">
				<div class="row">

					<div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-left-primary shadow h-100 py-2">
              <div class="card-body" style="padding:4px 20px;">
                <div class="row no-gutters align-items-center">
                  <div class="col mr-2">
                    <div class="text-md font-weight-bold text-primary text-uppercase mb-1" style="    height: 50px;">
                    Total Customers</div>
                    <div class="h4 mb-0 font-weight-bold text-gray-800">
                      46
                    </div>
                  </div>
                  <div class="col-auto">
                    <i class="fa fa-users  fa-2x text-gray-300"></i>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-left-success shadow h-100 py-2">
              <div class="card-body" style="padding:4px 20px;">
                <div class="row no-gutters align-items-center">
                  <div class="col mr-2">
                    <div class="text-md font-weight-bold text-success text-uppercase mb-1" style="    height: 50px;">
                    New Customers</div>
                    <div class="h4 mb-0 font-weight-bold text-gray-800">
                      0
                    </div>
                  </div>
                  <div class="col-auto">
                    <i class="fa fa-user  fa-2x text-gray-300"></i>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-left-warning shadow h-100 py-2">
              <div class="card-body" style="padding:4px 20px;">
                <div class="row no-gutters align-items-center">
                  <div class="col mr-2">
                    <div class="text-md font-weight-bold text-warning text-uppercase mb-1" style="    height: 50px;">
                    Total Products</div>
                    <div class="h4 mb-0 font-weight-bold text-gray-800">
                      15
                    </div>
                  </div>
                  <div class="col-auto">
                    <i class="fa fa-boxes  fa-2x text-gray-300"></i>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-left-info shadow h-100 py-2">
              <div class="card-body" style="padding:4px 20px;">
                <div class="row no-gutters align-items-center">
                  <div class="col mr-2">
                    <div class="text-md font-weight-bold text-info text-uppercase mb-1" style="    height: 50px;">
                    Avalible Products</div>
                    <div class="h4 mb-0 font-weight-bold text-gray-800">
                      14
                    </div>
                  </div>
                  <div class="col-auto">
                    <i class="fa fa-box  fa-2x text-gray-300"></i>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div class="col-md-9">
            <div class="row">
              <div class="col-md-6">
                <div class="card card-widget widget-user-2 shadow-sm" >
                  <div class="widget-user-header bg-primary" style="padding: 8px 24px;">
                    <h5 style="margin: 0px;">Orders</h5>
                  </div>
                  <div class="card-footer p-0">
                    <ul class="nav flex-column">
                      <li class="nav-item">
                        <a href="#" class="nav-link text-danger font-weight-bold">
                          New
                          <span class="float-right badge bg-danger" style="width: 40px; font-size: 15px;">100
                          </span>
                        </a>
                      </li>
                      <li class="nav-item">
                        <a href="#" class="nav-link text-warning font-weight-bold">
                          Accepted
                          <span class="float-right badge bg-warning" style="width: 40px; font-size: 15px;">
                          4
                          </span>
                        </a>
                      </li>
                      <li class="nav-item">
                        <a href="#" class="nav-link text-primary font-weight-bold">
                          Processing
                          <span class="float-right badge bg-primary" style="width: 40px; font-size: 15px;">
                          3
                          </span>
                        </a>
                      </li>
                      <li class="nav-item">
                        <a href="#" class="nav-link text-info font-weight-bold">
                          Cancelled
                          <span class="float-right badge bg-info" style="width: 40px; font-size: 15px;">
                          14
                          </span>
                        </a>
                      </li>
                      <li class="nav-item">
                        <a href="#" class="nav-link text-success font-weight-bold">
                          Delivered
                          <span class="float-right badge bg-success" style="width: 40px; font-size: 15px;">
                          4
                          </span>
                        </a>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>


            </div>
          </div>



        </div>
			</div>
		</section>

	</div>
</div>
<!-- /.content-wrapper -->
<footer class="main-footer">
	<strong>Copyright &copy; 2021-2022 <a href="">Thalir</a>.</strong>
	All rights reserved.
	<div class="float-right d-none d-sm-inline-block">
		Powered By <a href="https://erebsindia.com/" target="_blank"><b>EREbs</b></a>
	</div>
</footer>
<!-- jQuery -->
<script src="<?php echo e(asset('plugins/jquery/jquery.min.js')); ?>"></script>
<!-- jQuery UI 1.11.4 -->
<script src="<?php echo e(asset('plugins/jquery-ui/jquery-ui.min.js')); ?>"></script>
<!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
<script>
  $.widget.bridge('uibutton', $.ui.button)
</script>
<!-- Bootstrap 4 -->
<script src="<?php echo e(asset('plugins/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
<!-- Select2 -->
<script src="<?php echo e(asset('plugins/select2/js/select2.full.min.js')); ?>"></script>
<!-- ChartJS -->
<script src="<?php echo e(asset('plugins/chart.js/Chart.min.js')); ?>"></script>
<!-- Sparkline -->

<!-- JQVMap -->


<!-- jQuery Knob Chart -->

<!-- daterangepicker -->
<script src="<?php echo e(asset('plugins/moment/moment.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/daterangepicker/daterangepicker.js')); ?>"></script>
<!-- bootstrap color picker -->
<script src="<?php echo e(asset('plugins/bootstrap-colorpicker/js/bootstrap-colorpicker.min.js')); ?>"></script>
<!-- Tempusdominus Bootstrap 4 -->
<script src="<?php echo e(asset('plugins/tempusdominus-bootstrap-4/js/tempusdominus-bootstrap-4.min.js')); ?>"></script>
<!-- Summernote -->
<script src="<?php echo e(asset('plugins/summernote/summernote-bs4.min.js')); ?>"></script>
<!-- overlayScrollbars -->
<script src="<?php echo e(asset('plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js')); ?>"></script>
<!-- AdminLTE App -->
<script src="<?php echo e(asset('dist/js/adminlte.js')); ?>"></script>
<!-- jquery-validation -->
<script src="<?php echo e(asset('plugins/jquery-validation/jquery.validate.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/jquery-validation/additional-methods.min.js')); ?>"></script>
<!-- AdminLTE dashboard demo (This is only for demo purposes) -->
<script src="<?php echo e(asset('dist/js/pages/dashboard.js')); ?>"></script>
<!-- AdminLTE for demo purposes -->
<script src="<?php echo e(asset('dist/js/demo.js')); ?>"></script>
<!-- Toastr -->
<script src="<?php echo e(asset('plugins/toastr/toastr.min.js')); ?>"></script>

<style>
	.table-extra th {
    padding: 8px 4px !important;
    vertical-align: middle !important;
	}
</style>


</body>
</html>
<?php /**PATH E:\myprojects\NFCsmartcard\resources\views/adminhome.blade.php ENDPATH**/ ?>