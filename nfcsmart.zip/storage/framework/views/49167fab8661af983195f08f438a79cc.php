<?php $__env->startSection('content'); ?>
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0 text-dark">Campanies</h1>
                </div><!-- /.col -->
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="/admin">DashBoard</a></li>
                        <li class="breadcrumb-item active">
                            <a href="https://thalirnaturalsolutions.com/admin/products">Registrations</a>
                        </li>
                        <li class="breadcrumb-item active">Add Campanies</li>
                    </ol>
                </div><!-- /.col -->
            </div><!-- /.row -->
        </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->
    <div class="row m-10">
        <div class="col-12">
            <div class="card card-primary">
                <div class="card-header">
                    <h3 class="card-title">Add Campanies</h3>
                </div>
                <!-- form start -->
                <form action="">
                    <div class="card-body">
                        <div class="form-group row">
                            <label for="name" class="col-sm-3 col-form-label text-right">Campany Name:</label>
                            <div class="col-sm-6">
                                <input type="text" name="name" class="form-control" placeholder="Enter Campany Name">
                                <div id="name-span" class="invalid-feedback">Product Name Required.</div>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="name" class="col-sm-3 col-form-label text-right">Email Address:</label>
                            <div class="col-sm-6">
                                <input type="email" name="name" class="form-control" placeholder="Enter Email Address">
                                <div id="name-span" class="invalid-feedback">Product Name Required.</div>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="name" class="col-sm-3 col-form-label text-right">Password:</label>
                            <div class="col-sm-6">
                                <input type="text" name="name" class="form-control" placeholder="Enter Password">
                                <div id="name-span" class="invalid-feedback">Product Name Required.</div>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="name" class="col-sm-3 col-form-label text-right">Confirm Password:</label>
                            <div class="col-sm-6">
                                <input type="text" name="name" class="form-control" placeholder="Confirm Password">
                                <div id="name-span" class="invalid-feedback">Product Name Required.</div>
                            </div>
                        </div>
                    </div>

                    <div class="card-footer d-flex justify-content-center">
                        <button type="button" id="addBtn" class="btn btn-primary"> Save </button>
                    </div>
                    <!-- /.card-body -->
                </form>
            </div>
            <!-- /.card -->
        </div>
    </div>
    </div>
    <?php echo $__env->make('admin.layouts.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\myprojects\NFCsmartcard\resources\views/admin/registeration/campany_register_form.blade.php ENDPATH**/ ?>