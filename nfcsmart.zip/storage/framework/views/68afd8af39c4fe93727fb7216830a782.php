<?php $__env->startSection('content'); ?>


    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0 text-dark">Profile</h1>
                </div><!-- /.col -->
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="/admin">DashBoard</a></li>
                        <li class="breadcrumb-item active">
                            <a href="">Profile</a>
                        </li>
                        <li class="breadcrumb-item active">Add Profile</li>
                    </ol>
                </div><!-- /.col -->
            </div><!-- /.row -->
        </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->
    <div class="row m-10">
        <div class="col-12">
            <div class="card card-primary">
                <div class="card-header">
                    <h3 class="card-title">Add Profile</h3>
                    <input type="hidden" id="userid" value="">
                </div>
                <!-- form start -->

                <div class="card-body">
                    



                  

                        <form>
                            <div id="form2">
                                <h3 class="d-flex justify-content-center mt-1" style="font-family: 'Arial', sans-serif; font-size: 28px; font-weight: bold; text-align: center; text-transform: uppercase; color: #151449;">
                                    business profile
                                </h3>

                                <div class="form-group row">
                                    <label for="name" class="col-sm-3 col-form-label text-right">Business Name:</label>
                                    <div class="col-sm-6">
                                        <input type="text" id="bbusinessName" class="form-control"
                                            placeholder="Enter Business Name">
                                        <span class="bbusinessNameerror" style="color:red;font-size:16px"></span>
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <label for="image4" class="col-sm-3 col-form-label text-right">Logo :</label>
                                    <div class="col-sm-6 col-10">
                                        <div class="input-group">
                                            <div class="custom-file">
                                                <input class="custom-file-input" id="blogo" type="file">
                                                <label class="custom-file-label" for="image4">Choose file</label>
                                            </div>
                                        </div>
                                        <span class="error span-extra hide text-danger" id="helpimage4"></span>
                                    </div>
                                    <div class="col-sm-1 col-2">
                                        <button type="button" class="btn btn-secondary btn-tooltip float-left"
                                            data-toggle="tooltip" data-placement="top"
                                            title="Product in Aspect Ratio of 4:5 Required. ie Image with Resolution 200 x 250px, 300 x 375px etc.">
                                            <i class="fa fa-info" aria-hidden="true"></i>
                                        </button>
                                    </div>
                                    <span class="blogoerror" style="color:red;font-size:16px"></span>
                                </div>

                                <div class="form-group row">
                                    <label for="shopid" class="col-sm-3 col-form-label text-right">Industry:</label>
                                    <div class="col-sm-6">
                                        <select class="form-control" style="width: 100%;" id="bindustry">
                                            <option selected disabled>Select</option>
                                            <option value="technology">Technology</option>
                                            <option value="finance">Finance</option>
                                            <option value="retail">Retail</option>
                                        </select>
                                    </div>
                                    <span class="bindustryerror" style="color:red;font-size:16px"></span>
                                </div>

                                <div class="form-group row">
                                    <label for="disclaimer" class="col-sm-3 col-form-label text-right">Address :</label>
                                    <div class="col-sm-6">
                                        <textarea id="baddress" class="form-control"></textarea>
                                        <span class="baddresserror" style="color:red;font-size:16px"></span>
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <label for="name" class="col-sm-3 col-form-label text-right">Phone:</label>
                                    <div class="col-sm-6">
                                        <input type="tel" id="bphone" class="form-control"
                                            placeholder="Enter Your Phone Number">
                                        <span class="bphoneerror" style="color:red;font-size:16px"></span>
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <label for="name" class="col-sm-3 col-form-label text-right">Website:</label>
                                    <div class="col-sm-6">
                                        <input type="url" id="bwebsite" class="form-control"
                                            placeholder="Enter Your Website Url">
                                        <span class="bwebsiteerror" style="color:red;font-size:16px"></span>
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <label for="desc" class="col-sm-3 col-form-label text-right">Description :</label>
                                    <div class="col-sm-6">
                                        <textarea id="bdescription" class="ckeditor form-control"></textarea>
                                        <span class="bdescriptionerror" style="color:red;font-size:16px"></span>
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <label for="name" class="col-sm-3 col-form-label text-right">Social Media
                                        Profiles:</label>
                                    <div class="col-sm-6">
                                        <input type="url" id="binstagram" class="form-control"
                                            placeholder="Instagram Profile"><br>
                                        <input type="url" id="btwitter" class="form-control"
                                            placeholder="Twitter Profile"><br>
                                        <input type="url" id="blinkedin" class="form-control"
                                            placeholder="LinkedIn Profile"><br>
                                    </div>
                                </div>

                                <div class="card-footer">
                                    <a class="btn btn-default offset-sm-3" href="">Back</a>&emsp;
                                    <button type="button" id="addBtn" class="btn btn-primary" onclick="BusinessSave()">
                                        Save </button>
                                </div>


                            </div>
                        </form>


                </div>

            </div>
            <!-- /.card -->
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.js.user_profile_js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<script>


    function conditionModal() {

        $('#modal-condition').modal('show');
    }

    function conditionModalSave() {

        var newCondition = $('#newcondition').val();

        if (newCondition == '') {
            $('#newcondition').focus();
            $('#newcondition').css('border', '1px solid red');
            $('.newconditionerror').show().css('color', 'red').text("enter new condition here*");
            return false;
        } else {
            $('#newcondition').css('border', '1px solid #CCC');
            $('.newconditionerror').hide();
        }

        data = new FormData();

        data.append('newcondition', newCondition);
        data.append('_token', '<?php echo e(csrf_token()); ?>');

        $.ajax({
            type: "POST",
            url: "/profile-dropdown-save",
            data: data,
            dataType: "json",
            contentType: false,
            processData: false,
            success: function(data) {
                if (data['success']) {
                    toastr.success('Added successfully', '', {
                        timeOut: 1000,
                    });
                    $('#modal-condition').modal('hide');

                    $.post("/get-conditions", {
                        _token: "<?php echo e(csrf_token()); ?>"
                    }, function(result) {
                        $('#dropdown').html(result);
                    });
                } else {
                    toastr.error('Something Went Wrong');
                }
            }
        });

    }

    function AllergiModal() {
        $('#modal-allergy').modal('show');
    }

    function allergyModalSave() {
        var newAllergy = $('#newallergy').val();

        if (newAllergy == '') {
            $('#newallergy').focus();
            $('#newallergy').css('border', '1px solid red');
            $('.newallergyerror').show().css('color', 'red').text("enter new allergy here*");
            return false;
        } else {
            $('#newallergy').css('border', '1px solid #CCC');
            $('.newallergyerror').hide();
        }

        data = new FormData();

        data.append('newallergy', newAllergy);
        data.append('_token', '<?php echo e(csrf_token()); ?>');

        $.ajax({
            type: "POST",
            url: "/profile-dropdown-allergy-save",
            data: data,
            dataType: "json",
            contentType: false,
            processData: false,
            success: function(data) {
                if (data['success']) {
                    toastr.success('Added successfully', '', {
                        timeOut: 1000,
                    });
                    $('#modal-allergy').modal('hide');

                    $.post("/get-allergy", {
                        _token: "<?php echo e(csrf_token()); ?>"
                    }, function(result) {
                        $('#allergy').html(result);
                    });
                } else {
                    toastr.error('Something Went Wrong');
                }
            }
        });
    }
</script>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\myprojects\NFCsmartcard\resources\views/admin/registeration/user/profile_business_edit.blade.php ENDPATH**/ ?>