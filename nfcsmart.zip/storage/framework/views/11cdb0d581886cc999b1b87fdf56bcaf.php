<?php $__env->startSection('content'); ?>


    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0 text-dark">Profile</h1>
                </div><!-- /.col -->
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="/admin">DashBoard</a></li>
                        <li class="breadcrumb-item active">
                            <a href="">Profile</a>
                        </li>
                        <li class="breadcrumb-item active">Add Profile</li>
                    </ol>
                </div><!-- /.col -->
            </div><!-- /.row -->
        </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->
    <div class="row m-10">
        <div class="col-12">
            <div class="card card-primary">
                <div class="card-header">
                    <h3 class="card-title">Add Profile</h3>
                    <input type="hidden" id="userid" value="">
                </div>
                <!-- form start -->

                <div class="card-body">
                    



                        <form>
                            <div id="form1">
                                <h3 class="d-flex justify-content-center mt-1" style="font-family: 'Arial', sans-serif; font-size: 28px; font-weight: bold; text-align: center; text-transform: uppercase; color: #151449;">
                                    user profile
                                </h3>

                                <div class="form-group row">
                                    <label for="image4" class="col-sm-3 col-form-label text-right">Profile Pic :</label>
                                    <div class="col-sm-6 col-10">
                                        <div class="input-group">
                                            <div class="custom-file">
                                                <input class="custom-file-input" id="uimage" type="file">
                                                <label class="custom-file-label" for="image4">Choose file</label>
                                            </div>
                                        </div>

                                    </div>
                                    <div class="col-sm-1 col-2">
                                        <button type="button" class="btn btn-secondary btn-tooltip float-left"
                                            data-toggle="tooltip" data-placement="top"
                                            title="Product in Aspect Ratio of 4:5 Required. ie Image with Resolution 200 x 250px, 300 x 375px etc.">
                                            <i class="fa fa-info" aria-hidden="true"></i>
                                        </button>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-sm-9 offset-sm-3">
                                        <span class="uimageerror" style="color:red;font-size:16px"></span>
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <label for="name" class="col-sm-3 col-form-label text-right">Name:</label>
                                    <div class="col-sm-6">
                                        <input type="text" id="uname" class="form-control" placeholder="Enter Your Name">
                                        <span class="unameerror" style="color:red;font-size:16px"></span>
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <label for="name" class="col-sm-3 col-form-label text-right">Email:</label>
                                    <div class="col-sm-6">
                                        <input type="email" id="uemail" class="form-control"
                                            placeholder="Enter Your Email">
                                        <span class="uemailerror" style="color:red;font-size:16px"></span>
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <label for="name" class="col-sm-3 col-form-label text-right">Phone:</label>
                                    <div class="col-sm-6">
                                        <input type="tel" id="uphone" class="form-control"
                                            placeholder="Enter Your Phone Number">
                                        <span class="uphoneerror" style="color:red;font-size:16px"></span>
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <label for="name" class="col-sm-3 col-form-label text-right">Date of Birth:</label>
                                    <div class="col-sm-6">
                                        <input type="date" id="udob" class="form-control"
                                            placeholder="Enter Your DOB">
                                        <span class="udoberror" style="color:red;font-size:16px"></span>
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <label for="disclaimer" class="col-sm-3 col-form-label text-right">Address :</label>
                                    <div class="col-sm-6">
                                        <textarea id="uaddress" class="form-control"></textarea>
                                    </div>
                                    <span class="uaddresserror" style="color:red;font-size:16px"></span>
                                </div>

                                <div class="form-group row">
                                    <label for="disclaimer" class="col-sm-3 col-form-label text-right">Bio :</label>
                                    <div class="col-sm-6">
                                        <textarea id="uBio" class="ckeditor form-control"></textarea>
                                    </div>
                                    <span class="uBioerror" style="color:red;font-size:16px"></span>
                                </div>

                                <div class="form-group row mb-0">
                                    <label for="name" class="col-sm-3 col-form-label text-right">Social Media
                                        Profiles:</label>
                                    <div class="col-sm-6">
                                        <input type="url" id="uinstagram" class="form-control"
                                            placeholder="Instagram Profile"><br>
                                        <input type="url" id="utwitter" class="form-control"
                                            placeholder="Twitter Profile"><br>
                                        <input type="url" id="ulinkedin" class="form-control"
                                            placeholder="LinkedIn Profile">
                                    </div>
                                </div>

                                <h3 class="d-flex justify-content-center mt-1" style="font-family: 'Arial', sans-serif; font-size: 28px; font-weight: bold; text-align: center; text-transform: uppercase; color: #333;">
                                    Medical Details
                                </h3>


                                <div class="form-group row mb-4">
                                    <label for="name" class="col-sm-3 col-form-label text-right">Emergency
                                        Contact:</label>
                                    <div class="col-sm-6">
                                        <input type="text" id="fullname" class="form-control"
                                            placeholder="Full Name"><br>
                                        <input type="text" id="relationship" class="form-control"
                                            placeholder="Relationship to User"><br>
                                        <input type="tel" id="contact" class="form-control"
                                            placeholder="Contact Information">
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <label for="shopid" class="col-sm-3 col-form-label text-right">Chronic medical
                                        conditions:</label>
                                    <div class="col-sm-6" id="conditionhtml">
                                        <select class="form-control" style="width: 100%;" id="dropdown">

                                        </select>
                                        <a onclick="conditionModal()"><i class="fa-solid fa-circle-plus"
                                                style="color: #1f6ff9;position: absolute;right:-25px;top:5px;font-size:27px;"></i></a>
                                        
                                        
                                        <span class="ptypeerror" style="color:red;font-size:16px"></span>
                                    </div>
                                </div>


                                <div class="modal fade" id="modal-condition">
                                    <div class="modal-dialog modal-lg">
                                        <div class="modal-content">
                                            <form>
                                                <div class="modal-header">
                                                    <h4 class="modal-title" id="bannerHeading">Chronic medical conditions</h4>
                                                    <button type="button" class="close" data-dismiss="modal"
                                                        aria-label="Close">
                                                        <span aria-hidden="true">&times;</span>
                                                    </button>
                                                </div>
                                                <div class="modal-body">
                                                    <div class="card-body">
                                                        <div class="form-group row">
                                                            <form>
                                                        </div>
                                                        <div class="form-group row">
                                                            <label for="name"
                                                                class="col-sm-3 col-form-label text-right">Enter New
                                                                Condition*:</label>
                                                            <div class="col-sm-7">
                                                                <input class="form-control" placeholder="enter new condition"
                                                                    id="newcondition" type="text">
                                                                <span class="newconditionerror"
                                                                    style="color:red;font-size:16px"></span>
                                                            </div>

                                                        </div>
                                                    </div>
                                                    <!-- /.card-body -->
                                                </div>
                                                <div class="modal-footer justify-content-between">
                                                    <button type="button" class="btn btn-default"
                                                        data-dismiss="modal">Close</button>
                                                    <input type="hidden" id="userid">
                                                    <input class="btn btn-primary offset-sm-2" type="button" value="Save"
                                                        onclick="conditionModalSave()">
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>


                                <div class="form-group row">
                                    <label for="shopid" class="col-sm-3 col-form-label text-right">Allergies:</label>
                                    <div class="col-sm-6" style="position: relative">
                                        <select class="form-control" style="width: 100%;" id="allergy">

                                        </select><a onclick="AllergiModal()"><i class="fa-solid fa-circle-plus"
                                                style="color: #1f6ff9;position: absolute;right:-25px;top:5px;font-size:27px;"></i></a>
                                        
                                        
                                        <span class="ptypeerror" style="color:red;font-size:16px"></span>
                                    </div>
                                </div>

                                <div class="modal fade" id="modal-allergy">
                                    <div class="modal-dialog modal-lg">
                                        <div class="modal-content">
                                            <form>
                                                <div class="modal-header">
                                                    <h4 class="modal-title" id="bannerHeading">Allergies</h4>
                                                    <button type="button" class="close" data-dismiss="modal"
                                                        aria-label="Close">
                                                        <span aria-hidden="true">&times;</span>
                                                    </button>
                                                </div>
                                                <div class="modal-body">
                                                    <div class="card-body">
                                                        <div class="form-group row">
                                                            <form>
                                                        </div>
                                                        <div class="form-group row">
                                                            <label for="name"
                                                                class="col-sm-3 col-form-label text-right">Enter New
                                                                Allergy*:</label>
                                                            <div class="col-sm-7">
                                                                <input class="form-control" placeholder="enter new allergy"
                                                                    id="newallergy" type="text">
                                                                <span class="newallergyerror"
                                                                    style="color:red;font-size:16px"></span>
                                                            </div>

                                                        </div>
                                                    </div>
                                                    <!-- /.card-body -->
                                                </div>
                                                <div class="modal-footer justify-content-between">
                                                    <button type="button" class="btn btn-default"
                                                        data-dismiss="modal">Close</button>
                                                    <input type="hidden" id="userid">
                                                    <input class="btn btn-primary offset-sm-2" type="button" value="Save"
                                                        onclick="allergyModalSave()">
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <label for="shopid" class="col-sm-3 col-form-label text-right">Blood Type:</label>
                                    <div class="col-sm-6">
                                        <select class="form-control" style="width: 100%;" id="blood"
                                            onchange="aaa(this.value)">
                                            <option value="" selected disabled>Select</option>
                                            <option value="A+">A+</option>
                                            <option value="A-">A-</option>
                                            <option value="B+">B+</option>
                                            <option value="AB+">AB+</option>
                                            <option value="AB-">AB-</option>
                                            <option value="O+">O+</option>
                                            <option value="O-">O-</option>
                                        </select>
                                        <span class="ptypeerror" style="color:red;font-size:16px"></span>

                                    </div>
                                </div>

                                <div class="card-footer">
                                    <a class="btn btn-default offset-sm-3" href="">Back</a>&emsp;
                                    <button type="button" id="addBtn" class="btn btn-primary" onclick="UserSave()"> Save
                                    </button>
                                </div>


                            </div>
                        </form>

                        


                </div>

            </div>
            <!-- /.card -->
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.js.user_profile_js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<script>


    function conditionModal() {

        $('#modal-condition').modal('show');
    }

    function conditionModalSave() {

        var newCondition = $('#newcondition').val();

        if (newCondition == '') {
            $('#newcondition').focus();
            $('#newcondition').css('border', '1px solid red');
            $('.newconditionerror').show().css('color', 'red').text("enter new condition here*");
            return false;
        } else {
            $('#newcondition').css('border', '1px solid #CCC');
            $('.newconditionerror').hide();
        }

        data = new FormData();

        data.append('newcondition', newCondition);
        data.append('_token', '<?php echo e(csrf_token()); ?>');

        $.ajax({
            type: "POST",
            url: "/profile-dropdown-save",
            data: data,
            dataType: "json",
            contentType: false,
            processData: false,
            success: function(data) {
                if (data['success']) {
                    toastr.success('Added successfully', '', {
                        timeOut: 1000,
                    });
                    $('#modal-condition').modal('hide');

                    $.post("/get-conditions", {
                        _token: "<?php echo e(csrf_token()); ?>"
                    }, function(result) {
                        $('#dropdown').html(result);
                    });
                } else {
                    toastr.error('Something Went Wrong');
                }
            }
        });

    }

    function AllergiModal() {
        $('#modal-allergy').modal('show');
    }

    function allergyModalSave() {
        var newAllergy = $('#newallergy').val();

        if (newAllergy == '') {
            $('#newallergy').focus();
            $('#newallergy').css('border', '1px solid red');
            $('.newallergyerror').show().css('color', 'red').text("enter new allergy here*");
            return false;
        } else {
            $('#newallergy').css('border', '1px solid #CCC');
            $('.newallergyerror').hide();
        }

        data = new FormData();

        data.append('newallergy', newAllergy);
        data.append('_token', '<?php echo e(csrf_token()); ?>');

        $.ajax({
            type: "POST",
            url: "/profile-dropdown-allergy-save",
            data: data,
            dataType: "json",
            contentType: false,
            processData: false,
            success: function(data) {
                if (data['success']) {
                    toastr.success('Added successfully', '', {
                        timeOut: 1000,
                    });
                    $('#modal-allergy').modal('hide');

                    $.post("/get-allergy", {
                        _token: "<?php echo e(csrf_token()); ?>"
                    }, function(result) {
                        $('#allergy').html(result);
                    });
                } else {
                    toastr.error('Something Went Wrong');
                }
            }
        });
    }
</script>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\myprojects\NFCsmartcard\resources\views/admin/registeration/user/profile_user_edit.blade.php ENDPATH**/ ?>