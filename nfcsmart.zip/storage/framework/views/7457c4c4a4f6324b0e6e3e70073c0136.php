<?php $__env->startSection('content'); ?>
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0 text-dark">User Profile</h1>
                </div><!-- /.col -->
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="/">DashBoard</a></li>
                        <li class="breadcrumb-item active">Registrations</li>
                        <li class="breadcrumb-item active">Users</li>
                        <li class="breadcrumb-item active">Users list</li>
                        <li class="breadcrumb-item active">User Profile</li>
                    </ol>
                </div><!-- /.col -->
            </div><!-- /.row -->
        </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <div class="row m-20">
        <div class="col-md-12">
            <div class="card card-primary">
                <div class="card-header">
                    <h3 class="card-title">Profile</h3>
                </div>
                <div class="card-body table-responsive p-0">
                    <table class="table table-hover text-nowrap table-bordered table-extra">
                        <input type="hidden" id="userid" value="<?php echo e($UserID); ?>">
                        <thead>
                            <tr>
                                <th>Sl.No</th>
                                <th>Profile Type</th>
                                <th>Name</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $profiles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $profile): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td align="center"><?php echo e($loop->iteration); ?></td>
                                    <?php if($profile->profile_type == 1): ?>
                                        <td align="center">User Profile</td>
                                    <?php else: ?>
                                        <td align="center">Business profile</td>
                                    <?php endif; ?>

                                    <?php if($profile->profile_type == 1): ?>
                                        <td align="center"><?php echo e($profile->user_name); ?></td>
                                    <?php else: ?>
                                        <td align="center"><?php echo e($profile->business_name); ?></td>
                                    <?php endif; ?>

                                    <td align="center">
                                        <div class="col-sm-3" align="center">
                                            <!-- Updated code for the create profile button/link -->
                                            <a class="btn btn-sm btn-success" target="_blank" style="color: white;"
                                                href="<?php echo e(route('profilepreviw', $profile->id)); ?>">
                                                <i class="fa fa-eye" style="font-size:16px"></i><b
                                                    style="margin-left: 3px;">Preview</b>
                                            </a>
                                            <a class="btn btn-sm btn-primary" target="" style="color: white;"
                                                href="<?php echo e(route('profiledit', ['id' => $profile->id, 'user_id' => $profile->user_id])); ?>">
                                                <i class="fa fa-pencil" style="font-size: 16px;"></i><b
                                                    style="margin-left: 3px;">Edit</b>
                                            </a>

                                            <a class="btn btn-sm btn-danger" style="color: white;"
                                                onclick="profileDelete('<?php echo e($profile->id); ?>')">
                                                <i class="fa fa-trash" style="font-size: 16px;"></i><b
                                                    style="margin-left: 3px;">Delete</b>
                                            </a>
                                        </div>
                                    </td>

                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                    </table>
                </div>
                <!-- /.card-body -->
                <div class="card-footer clearfix d-flex justify-content-center">
                    <?php echo e($profiles->links()); ?>

                </div>
            </div>
            <!-- /.card -->
        </div>
    </div>
    <!-- Add new Banner link -->
    <a onclick="ProfileChooseShow()">
        <i class="fa fa-plus-circle fa-add-new" aria-hidden="true"></i>
    </a>
    </div>
    
    
    
    
    
    
    
    
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.js.user_profile_js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script>
    function profileDelete(pid) {
        data = new FormData();
        data.append('pid', pid);
        data.append('_token', '<?php echo e(csrf_token()); ?>');

        Swal.fire({
            title: 'Do You Want To Delete..??',
            icon: 'question',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes'
        }).then((result) => {
            if (result.isConfirmed) {
                $.ajax({
                    type: "POST",
                    url: "/profile-delete",
                    data: data,
                    dataType: "json",
                    contentType: false,
                    processData: false,
                    success: function(data) {
                        if (data['success']) {
                            toastr.success('Deleted successfully', '', {
                                timeOut: 1000,
                            });

                            // Refresh the page after displaying Toastr notification
                            setTimeout(function() {
                                window.location.reload();
                            }, 1000); // Change the delay as needed
                        } else {
                            toastr.error('Something Went Wrong');
                        }
                    }
                });
            }
        });
    }
</script>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\myprojects\NFCsmartcard\resources\views/admin/registeration/user/user_profile.blade.php ENDPATH**/ ?>